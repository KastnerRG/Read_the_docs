#!/usr/bin/env python
# coding: utf-8

# In[10]:


import time
from pynq import Overlay
import pynq.lib.dma
#from pynq import Xlnk
import numpy as np
from pynq import MMIO
import random

print("Programming the FPGA")
ol = Overlay('./smul.bit') # check your path
ol.download() # it downloads your bit to FPGA


# In[11]:


print("Inspect all the IP names")
ol.ip_dict.keys()


# In[12]:


print("Inspect the HLS IP registers")
hls_ip = ol.smul
print(hls_ip)
# hls_ip.register_map


# In[13]:


# Setup recv/send DMA 
dma = ol.smul_dma
dma_send = ol.smul_dma.sendchannel
dma_recv = ol.smul_dma.recvchannel

#dma = ol.axi_dma_0
#dma_send = ol.axi_dma_0.sendchannel
#dma_recv = ol.axi_dma_0.recvchannel


# In[14]:


print("Starting HLS IP")
hls_ip.register_map
CONTROL_REGISTER = 0x0
hls_ip.write(CONTROL_REGISTER, 0x81) # 0x81 will set bit 0
# hls_ip.register_map


# In[15]:


# Prepare data to send 
from pynq import allocate
import numpy as np

data_size = 20
input_buffer = allocate(shape=(data_size,), dtype=np.uint32)
output_buffer = allocate(shape=(data_size,), dtype=np.uint32)

for i in range(data_size):
    input_buffer[i] = i


# In[16]:


print("Starting DMA transfer")
dma_recv.transfer(output_buffer)
dma_send.transfer(input_buffer)

dma_send.wait()
dma_recv.wait()


# In[17]:


# Print the data 
for i in range(data_size):
    #print('0x' + format(output_buffer[i], '02x'))
    print(i, input_buffer[i], output_buffer[i])

    
print("Finished!!!")


# In[18]:


del input_buffer
del output_buffer
del ol
print("Finished!")


# In[ ]:




